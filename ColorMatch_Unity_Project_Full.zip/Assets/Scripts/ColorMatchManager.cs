
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class ColorMatchManager : MonoBehaviour
{
    public Image targetColorDisplay;
    public List<Button> colorButtons;
    public Text feedbackText;

    private Color targetColor;
    private Dictionary<string, Color> colorMap;

    void Start()
    {
        colorMap = new Dictionary<string, Color>()
        {
            { "Red", Color.red },
            { "Blue", Color.blue },
            { "Green", Color.green },
            { "Yellow", Color.yellow }
        };

        AssignButtonListeners();
        SetRandomTargetColor();
    }

    void AssignButtonListeners()
    {
        foreach (var button in colorButtons)
        {
            string colorName = button.name;
            button.onClick.AddListener(() => OnColorButtonClicked(colorName));
        }
    }

    void SetRandomTargetColor()
    {
        int index = Random.Range(0, colorMap.Count);
        string colorName = new List<string>(colorMap.Keys)[index];
        targetColor = colorMap[colorName];
        targetColorDisplay.color = targetColor;
        feedbackText.text = "Match the color!";
    }

    void OnColorButtonClicked(string colorName)
    {
        if (colorMap[colorName] == targetColor)
        {
            feedbackText.text = "✅ Good Job!";
        }
        else
        {
            feedbackText.text = "❌ Try Again!";
        }

        Invoke("SetRandomTargetColor", 1.5f);
    }
}
